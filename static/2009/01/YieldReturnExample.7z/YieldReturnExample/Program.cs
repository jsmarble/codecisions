﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace YieldReturnExample
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers = LoadNumbersUsingList(1, 10);
            WriteNumbers(numbers);
            numbers = LoadNumbersUsingYield(1, 10);
            WriteNumbers(numbers);
            Console.ReadLine();
        }

        static IEnumerable<int> LoadNumbersUsingList(int minimum, int maximum)
        {
            List<int> numbers = new List<int>(maximum - minimum);
            for (int i = minimum; i <= maximum; i++)
                numbers.Add(i);
            return numbers;
        }

        static IEnumerable<int> LoadNumbersUsingYield(int minimum, int maximum)
        {
            for (int i = minimum; i <= maximum; i++)
                yield return i;
        }

        static void WriteNumbers(IEnumerable<int> numbers)
        {
            foreach (int number in numbers)
                Console.WriteLine(number);
        }
    }
}
