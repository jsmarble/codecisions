﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ConversionOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            TestExplicit();
            TestImplicit();
            TestOperators();
        }

        private static void TestOperators()
        {
            Dog d = new Dog();
            Cat c = new Cat();

            Assert.IsTrue(c < d);
            Assert.IsFalse(d < c);

            Assert.IsTrue(d > c);
            Assert.IsFalse(c > d);

            Assert.IsFalse(c > c);
            Assert.IsFalse(d < d);
        }

        static void TestExplicit()
        {
            Dog d = new Dog("Biscuit");
            Cat c = d;
            Assert.AreEqual(d.Name, c.Name);
        }

        static void TestImplicit()
        {
            Cat c = new Cat("Sprinkles");
            Dog d = (Dog)c;
            Assert.AreEqual(c.Name, d.Name);
        }
    }

    public class Dog
    {
        public Dog()
        {
            this.Birthdate = DateTime.Today.AddDays(-1);
        }

        public Dog(string name)
            : this()
        {
            this.Name = name;
        }

        public DateTime Birthdate { get; set; }
        public string Name { get; set; }

        public int Age
        {
            get
            {
                return (int)(Math.Floor(DateTime.Today.Subtract(this.Birthdate).TotalDays / 365));
            }
        }

        public static bool operator <(Dog x, Dog y)
        {
            return x.Age < y.Age;
        }

        public static bool operator >(Dog x, Dog y)
        {
            return x.Age > y.Age;
        }

        public static bool operator >(Dog x, Cat y)
        {
            return x.Age > x.Age;
        }

        public static bool operator <(Dog x, Cat y)
        {
            return x.Age < y.Age;
        }

        public static implicit operator Cat(Dog dog)
        {
            return new Cat(dog.Name);
        }
    }

    public class Cat
    {
        public Cat()
        {
            this.Birthdate = DateTime.Today;
        }

        public Cat(string name)
            : this()
        {
            this.Name = name;
        }

        public DateTime Birthdate { get; set; }
        public string Name { get; set; }

        public int Age
        {
            get
            {
                return (int)(Math.Floor(DateTime.Today.Subtract(this.Birthdate).TotalDays / 365));
            }
        }

        public static bool operator >(Cat x, Dog y)
        {
            return x.Age > x.Age;
        }

        public static bool operator <(Cat x, Dog y)
        {
            return x.Age < y.Age;
        }

        public static bool operator <(Cat x, Cat y)
        {
            return x.Age < y.Age;
        }

        public static bool operator >(Cat x, Cat y)
        {
            return x.Age > y.Age;
        }

        public static explicit operator Dog(Cat cat)
        {
            return new Dog(cat.Name);
        }
    }
}
