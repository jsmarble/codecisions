﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace WCFService1.ServiceModel
{
    [ServiceContract]
    public interface IGuidService
    {
        [OperationContract]
        Guid GetNewGuid();
    }
}
