﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCFService1.ServiceModel;
using System.ServiceModel;

namespace WCFService1
{
    internal class GuidWebServiceClient : ClientBase<IGuidService>, IGuidService
    {
        #region IGuidService Members

        public Guid GetNewGuid()
        {
            return base.Channel.GetNewGuid();
        }

        #endregion
    }
}
