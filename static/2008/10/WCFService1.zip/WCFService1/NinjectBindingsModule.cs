﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ninject.Core;
using WCFService1.ServiceModel;
using WCFService1.LocalService;
using Ninject.Core.Activation;

namespace WCFService1
{
    internal class NinjectBindingsModule : StandardModule
    {
        public override void Load()
        {
            Bind<IGuidService>().To<GuidService>();
            Bind<IGuidService>().To<GuidWebServiceClient>().OnlyIf(new Predicate<IContext>(UseWebService));
        }

        private bool UseWebService(IContext context)
        {
            return true;
        }
    }
}
