﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using WCFService1.ServiceModel;

namespace WCFService1.WebService
{
    [ServiceBehavior]
    public class GuidWebService : IGuidService
    {

        #region IGuidService Members

        [OperationBehavior]
        public Guid GetNewGuid()
        {
            return Guid.NewGuid();
        }

        #endregion
    }
}
