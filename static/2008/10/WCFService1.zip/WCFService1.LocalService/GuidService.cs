﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WCFService1.ServiceModel;

namespace WCFService1.LocalService
{
    public class GuidService : IGuidService
    {
        #region IGuidService Members

        public Guid GetNewGuid()
        {
            return Guid.NewGuid();
        }

        #endregion
    }
}
